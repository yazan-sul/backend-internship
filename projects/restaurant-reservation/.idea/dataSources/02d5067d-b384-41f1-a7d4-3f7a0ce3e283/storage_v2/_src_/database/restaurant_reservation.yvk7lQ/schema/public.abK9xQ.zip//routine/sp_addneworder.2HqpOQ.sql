create procedure sp_addneworder(IN reservationid integer, IN employeeid integer, IN orderdate timestamp with time zone, IN totalamount numeric, OUT neworderid integer)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM reservations AS reservation
        WHERE reservation.reservation_id = ReservationId
    ) THEN
        RAISE EXCEPTION 'Reservation % does not exist', ReservationId;
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM employees AS employee
        WHERE employee.employee_id = EmployeeId
    ) THEN
        RAISE EXCEPTION 'Employee % does not exist', EmployeeId;
    END IF;

    INSERT INTO orders (
        reservation_id,
        employee_id,
        order_date,
        total_amount
    )
    VALUES (
        ReservationId,
        EmployeeId,
        OrderDate,
        TotalAmount
    )
    RETURNING order_id INTO NewOrderId;
END;
$$;

alter procedure sp_addneworder(integer, integer, timestamp with time zone, numeric, out integer) owner to postgres;

