create function fn_calculateemployeesalary(employeeid integer) returns numeric
    language sql
as
$$
WITH EmployeeOrders AS (
    SELECT
        employee.position,
        COUNT(orders.order_id) AS total_orders
    FROM employees AS employee
    LEFT JOIN orders
        ON orders.employee_id = employee.employee_id
    WHERE employee.employee_id = EmployeeId
    GROUP BY employee.employee_id,
          employee.position
)
SELECT
    CASE
        WHEN position = 'VIPOrdersWaiter' THEN total_orders * 5
        WHEN position = 'StandardWaiter' THEN total_orders * 4
        WHEN position = 'AssistantWaiter' THEN total_orders * 3
        ELSE 0
    END
FROM EmployeeOrders;
$$;

alter function fn_calculateemployeesalary(integer) owner to postgres;

