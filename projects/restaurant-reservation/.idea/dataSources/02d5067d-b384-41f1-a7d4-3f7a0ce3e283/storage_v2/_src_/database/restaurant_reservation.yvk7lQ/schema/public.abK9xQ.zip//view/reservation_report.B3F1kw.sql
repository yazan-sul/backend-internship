create view reservation_report
            (reservation_id, reservation_date, party_size, customer_id, customer_first_name, customer_last_name,
             customer_email, customer_phone_number, restaurant_id, restaurant_name, restaurant_address,
             restaurant_phone_number)
as
SELECT reservation.reservation_id,
       reservation.reservation_date,
       reservation.party_size,
       customer.customer_id,
       customer.first_name     AS customer_first_name,
       customer.last_name      AS customer_last_name,
       customer.email          AS customer_email,
       customer.phone_number   AS customer_phone_number,
       restaurant.restaurant_id,
       restaurant.name         AS restaurant_name,
       restaurant.address      AS restaurant_address,
       restaurant.phone_number AS restaurant_phone_number
FROM reservations reservation
         JOIN customers customer ON customer.customer_id = reservation.customer_id
         JOIN restaurants restaurant ON restaurant.restaurant_id = reservation.restaurant_id
ORDER BY reservation.reservation_date;

alter table reservation_report
    owner to postgres;

