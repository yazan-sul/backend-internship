create function fn_calculaterevenue(restaurantid integer) returns numeric
    language sql
as
$$
  SELECT
    SUM(restaurant_order.total_amount) AS total_revenue
  FROM
    reservations AS reservation
    JOIN orders AS restaurant_order ON restaurant_order.reservation_id = reservation.reservation_id
  WHERE
    reservation.restaurant_id = RestaurantId
    $$;

alter function fn_calculaterevenue(integer) owner to postgres;

