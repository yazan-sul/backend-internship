create procedure sp_resrvedtablesreport(IN startdate timestamp with time zone, IN enddate timestamp with time zone, INOUT reportcursor refcursor DEFAULT 'reserved_tables_report'::refcursor)
    language plpgsql
as
$$
BEGIN
    IF StartDate IS NULL OR EndDate IS NULL THEN
        RAISE EXCEPTION 'StartDate and EndDate are required';
    END IF;

    IF StartDate > EndDate THEN
        RAISE EXCEPTION 'StartDate must be earlier than or equal to EndDate';
    END IF;

    OPEN ReportCursor FOR
        SELECT
            reservation.reservation_id,
            reservation.reservation_date,
            reservation.party_size,
            restaurant_table.table_id,
            restaurant_table.table_number,
            restaurant_table.capacity AS table_capacity,
            restaurant.restaurant_id,
            restaurant.name AS restaurant_name,
            restaurant.address AS restaurant_address,
            restaurant.phone_number AS restaurant_phone_number
        FROM reservations AS reservation
        INNER JOIN restaurant_tables AS restaurant_table
            ON restaurant_table.table_id = reservation.table_id
        INNER JOIN restaurants AS restaurant
            ON restaurant.restaurant_id = reservation.restaurant_id
        WHERE reservation.reservation_date BETWEEN StartDate AND EndDate
        ORDER BY
            reservation.reservation_date,
            restaurant.name,
            restaurant_table.table_number,
            reservation.reservation_id;
END;
$$;

alter procedure sp_resrvedtablesreport(timestamp with time zone, timestamp with time zone, inout refcursor) owner to postgres;

