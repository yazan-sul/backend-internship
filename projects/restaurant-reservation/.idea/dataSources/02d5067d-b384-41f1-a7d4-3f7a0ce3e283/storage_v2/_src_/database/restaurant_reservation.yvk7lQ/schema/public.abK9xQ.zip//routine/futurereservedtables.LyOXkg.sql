create procedure futurereservedtables()
    language plpgsql
as
$$
  BEGIN
      DROP TABLE IF EXISTS temp_future_tables;

      CREATE TEMP TABLE temp_future_tables AS
      SELECT DISTINCT table_id, restaurant_id
      FROM reservations
      WHERE reservation_date > CURRENT_TIMESTAMP;
  END;
  $$;

alter procedure futurereservedtables() owner to postgres;

