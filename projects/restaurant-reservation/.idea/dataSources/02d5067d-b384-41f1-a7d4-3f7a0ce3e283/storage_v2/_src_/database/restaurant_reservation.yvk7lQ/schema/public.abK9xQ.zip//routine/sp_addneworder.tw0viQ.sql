create procedure sp_addneworder(IN reservationid integer, IN employeeid integer, IN orderdate timestamp with time zone, IN totalamount numeric, INOUT neworderid integer DEFAULT NULL::integer, INOUT errormessage text DEFAULT NULL::text)
    language plpgsql
as
$$
DECLARE
    reservation_restaurant_id integer;
    employee_restaurant_id integer;
BEGIN
    NewOrderId := NULL;
    ErrorMessage := NULL;

    SELECT reservation.restaurant_id
    INTO reservation_restaurant_id
    FROM reservations AS reservation
    WHERE reservation.reservation_id = ReservationId;

    IF NOT FOUND THEN
        ErrorMessage := format('Reservation %s does not exist', ReservationId);
        RETURN;
    END IF;

    SELECT employee.restaurant_id
    INTO employee_restaurant_id
    FROM employees AS employee
    WHERE employee.employee_id = EmployeeId;

    IF NOT FOUND THEN
        ErrorMessage := format('Employee %s does not exist', EmployeeId);
        RETURN;
    END IF;

    IF employee_restaurant_id <> reservation_restaurant_id THEN
        ErrorMessage := format(
            'Employee %s does not work at the reservation restaurant',
            EmployeeId
        );
        RETURN;
    END IF;

    IF OrderDate IS NULL THEN
        ErrorMessage := 'OrderDate is required';
        RETURN;
    END IF;

    IF TotalAmount IS NULL OR TotalAmount < 0 THEN
        ErrorMessage := 'TotalAmount must be zero or greater';
        RETURN;
    END IF;

    INSERT INTO orders (reservation_id, employee_id, order_date, total_amount)
    VALUES (ReservationId, EmployeeId, OrderDate, TotalAmount)
    RETURNING order_id INTO NewOrderId;
END;
$$;

alter procedure sp_addneworder(integer, integer, timestamp with time zone, numeric, inout integer, inout text) owner to postgres;

