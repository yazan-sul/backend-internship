create function menu_items(orderid integer)
    returns TABLE(name text, price numeric)
    language sql
as
$$ 
SELECT
  name,
  unit_price AS price
FROM
  orders
  JOIN order_items ON orders.order_id = order_items.order_id
  JOIN menu_items ON order_items.item_id = menu_items.item_id
  WHERE orders.order_id = OrderID
  $$;

alter function menu_items(integer) owner to postgres;

