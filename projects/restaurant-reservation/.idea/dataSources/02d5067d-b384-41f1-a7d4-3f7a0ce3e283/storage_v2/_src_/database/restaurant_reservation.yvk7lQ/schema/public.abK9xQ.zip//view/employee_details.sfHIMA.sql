create view employee_details
            (employee_id, first_name, last_name, employee_name, position, restaurant_id, restaurant_name,
             restaurant_address, restaurant_phone_number, restaurant_opening_hours)
as
SELECT employee.employee_id,
       employee.first_name,
       employee.last_name,
       concat(employee.first_name, ' ', employee.last_name) AS employee_name,
       employee."position",
       restaurant.restaurant_id,
       restaurant.name                                      AS restaurant_name,
       restaurant.address                                   AS restaurant_address,
       restaurant.phone_number                              AS restaurant_phone_number,
       restaurant.opening_hours                             AS restaurant_opening_hours
FROM employees employee
         JOIN restaurants restaurant ON restaurant.restaurant_id = employee.restaurant_id;

alter table employee_details
    owner to postgres;

