create view reservation_details
            (reservation_id, reservation_date, party_size, customer_id, customer_name, customer_email,
             customer_phone_number, restaurant_id, restaurant_name, table_id, table_number, table_capacity)
as
SELECT reservation.reservation_id,
       reservation.reservation_date,
       reservation.party_size,
       customer.customer_id,
       concat(customer.first_name, ' ', customer.last_name) AS customer_name,
       customer.email                                       AS customer_email,
       customer.phone_number                                AS customer_phone_number,
       restaurant.restaurant_id,
       restaurant.name                                      AS restaurant_name,
       restaurant_table.table_id,
       restaurant_table.table_number,
       restaurant_table.capacity                            AS table_capacity
FROM reservations reservation
         JOIN customers customer ON customer.customer_id = reservation.customer_id
         JOIN restaurants restaurant ON restaurant.restaurant_id = reservation.restaurant_id
         JOIN restaurant_tables restaurant_table ON restaurant_table.table_id = reservation.table_id;

comment on view reservation_details is 'Reservation report with customer, restaurant, and assigned-table details.';

alter table reservation_details
    owner to postgres;

