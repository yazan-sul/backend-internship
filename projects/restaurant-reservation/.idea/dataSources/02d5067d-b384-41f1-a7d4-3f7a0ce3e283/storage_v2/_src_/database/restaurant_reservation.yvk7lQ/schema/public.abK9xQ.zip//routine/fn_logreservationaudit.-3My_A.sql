create function fn_logreservationaudit() returns trigger
    language plpgsql
as
$$
  BEGIN
      INSERT INTO audit_log (
          restaurant_id,
          table_id,
          reservation_date,
          change_date
      )
      VALUES (
          NEW.restaurant_id,
          NEW.table_id,
          NEW.reservation_date,
          CURRENT_TIMESTAMP
      );

      RETURN NEW;
  END;
  $$;

alter function fn_logreservationaudit() owner to postgres;

