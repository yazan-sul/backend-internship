create view employee_report
            (employee_id, employee_name, position, restaurant_id, restaurant_name, restaurant_address,
             restaurant_phone_number) as
SELECT employee.employee_id,
       concat(employee.first_name, ' ', employee.last_name) AS employee_name,
       employee."position",
       restaurant.restaurant_id,
       restaurant.name                                      AS restaurant_name,
       restaurant.address                                   AS restaurant_address,
       restaurant.phone_number                              AS restaurant_phone_number
FROM employees employee
         JOIN restaurants restaurant ON restaurant.restaurant_id = employee.restaurant_id;

alter table employee_report
    owner to postgres;

