create procedure sp_futurereservedtablesreport(INOUT reportcursor refcursor DEFAULT 'future_reserved_tables_report'::refcursor)
    language plpgsql
as
$$
BEGIN
    DROP TABLE IF EXISTS pg_temp.future_reserved_tables;

    CREATE TEMPORARY TABLE future_reserved_tables
    ON COMMIT DROP
    AS
    SELECT
        reservation.reservation_id,
        reservation.restaurant_id,
        reservation.table_id,
        reservation.reservation_date,
        reservation.party_size
    FROM reservations AS reservation
    WHERE reservation.reservation_date > current_timestamp;

    OPEN ReportCursor FOR
        SELECT
            future_reservation.reservation_id,
            future_reservation.reservation_date,
            future_reservation.party_size,
            restaurant_table.table_id,
            restaurant_table.table_number,
            restaurant_table.capacity AS table_capacity,
            restaurant.restaurant_id,
            restaurant.name AS restaurant_name,
            restaurant.address AS restaurant_address,
            restaurant.phone_number AS restaurant_phone_number,
            restaurant.opening_hours
        FROM pg_temp.future_reserved_tables AS future_reservation
        INNER JOIN restaurant_tables AS restaurant_table
            ON restaurant_table.table_id = future_reservation.table_id
        INNER JOIN restaurants AS restaurant
            ON restaurant.restaurant_id = future_reservation.restaurant_id
        ORDER BY
            future_reservation.reservation_date,
            restaurant.name,
            restaurant_table.table_number,
            future_reservation.reservation_id;
END;
$$;

alter procedure sp_futurereservedtablesreport(inout refcursor) owner to postgres;

