create function log_reservation_audit() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO audit_log (
        restaurant_id,
        table_id,
        reservation_date,
        change_date
    )
    VALUES (
        NEW.restaurant_id,
        NEW.table_id,
        NEW.reservation_date,
        CURRENT_TIMESTAMP
    );

    RETURN NEW;
END;
$$;

alter function log_reservation_audit() owner to postgres;

